def display_string2(text):
    print("******" + text + "******")

def display_string2(text):
        print("<<<<" + text + ">>>>")