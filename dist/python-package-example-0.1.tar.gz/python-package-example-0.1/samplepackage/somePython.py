
def make_upper_case(text):
    return text.title()


def add_exclamation(text):
    return text + "!"