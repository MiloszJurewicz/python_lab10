def display_string(text):
    print ("******" + text + "******")